LogScrobbler is a small application that is intended to sync your .scrobbler.log files from portable audio players to last.fm
it is written in C# .NET 2.0.

I wrote this for myself to sync my logs, thought some others might also find it useful, please use at your own risk, as I will not be responsible for any damage this may cause to your computer, audio player, or any other device, software, or anything.

Thanks,

kernelsandirs@gmail.com
Email with any suggestions or feedback.
============================================

Changelog:

0.6
x I think this fixes some issue with safely removing usb device.
+ added setting for exit after processing complete
+ added progress bar.
+ added this file :-)

0.5
+ added selectable list to sync
x fixed small bugs


0.1 - 0.4 
Don't remember all the items - started this file at 0.6 :-(
+ added about window
+ Delete file after processing option
+ Save settings

